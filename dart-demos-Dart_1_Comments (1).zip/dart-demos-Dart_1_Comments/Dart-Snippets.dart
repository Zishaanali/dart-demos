void main() {
  // The following line of code will print a text on console
  print("My name is Khan");

  /*
   We are currently learning Dart code 
   because we need to work on the
   Flutter framework
   */
}
